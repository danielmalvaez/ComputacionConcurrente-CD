public class Testeo {
    public static void main(String[] args) {
        CocineroMesero c = new CocineroMesero();
        c.CocineroMeseroDemo();
      }
}